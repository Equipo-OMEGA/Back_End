<?php
//Hacemos una conexion a la base de datos en la cual se espesifica que sera de manera local, un usuario
// una contraseña ( en este caso no tiene la base de datos) y el nombre de la base de datos
$conn= mysqli_connect("localhost:3306","root", "", "sistema");

?>