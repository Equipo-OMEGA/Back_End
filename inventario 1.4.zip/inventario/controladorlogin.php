<?php

//Obtiene los datos de los campos del login  
$Usuario=$_POST['Usuario'];
$Contraseña=$_POST['Contraseña'];
//Desemcripta la contraseña que se recupera de la base de datos
$Contraseña = hash('sha512', $Contraseña);
//se inicia la sesion del usuario registrado con ese campo
session_start();
$_SESSION['Usuario']=$Usuario;
//Hacemos una conexion a la base de datos en la cual se espesifica que sera de manera local, un usuario
//una contraseña ( en este caso no tiene la base de datos) y el nombre de la base de datos
$conexion=mysqli_connect("localhost:3306","root","","inventario");

//Hacemos una consulta a nuestra base de datos en la que seleccionara los campos y el contenido de este y lo 
//comparara con los datos dados por el usuario 
$consulta="SELECT * FROM usuario where Usuario='$Usuario' and Contraseña='$Contraseña'";
//Variable en donde se almacena el resultado de la consulta(sql, query) y la coneccion a la base de datos
$resultado=mysqli_query($conexion,$consulta);
//Esta variable regresa los resultados de la variable "resultados" 
$filas=mysqli_num_rows($resultado);

//si "filas tiene los resultados de la consulta y estos concuerdan con el correo electronico y la contraseña 
//de la base de datos, entonces mandara al usuario al archivo home
if($filas){ 
    header("location: home.php");

}else{
    ?>
    <?php
    include("index.html");
    ?>
    <link rel="stylesheet" type="text/css" href="Styles/Inicio de Sesión.css">
    <div class="error-message"> <!-- Contenedor para mensajes de error -->
        <div class = error-cntainer>
            <center><p>La Contraseña o el usuario es incorrecto</p></center>
        </div>
    </div>
    <style>
        .error-cntainer {
            width: 386px;
            background-color: #fff; /* Establece el color de fondo del contenedor */
            border-radius: 20px; /* Redondea los bordes del contenedor*/
            box-shadow: 0px 10px 10px 0px rgba(0, 0, 0, 0.2); /* Agrega una sombra suave alrededor del contenedor */
            padding: 35px; /* Añade espacio dentro del contenedor */
            top: 88%;/* Cambial la posicion de la caja de texto hacia abajo*/
            left: 50%;/*cambial la posicion de la caja de texto hacia la derecha */
            position: absolute;/*La posicion de la caja no depende de un punto fijo en la pantalla*/
            transform: translate(-50%, -50%);/*Traslada la posicion de la caja a los valores asignados */
            box-sizing: border-box;/*Le crea un brde a la caja */
        }
    </style> <!-- Mensaje de error que se mostrará en caso de credenciales incorrectas -->

    <?php
}
mysqli_free_result($resultado);
//Cierra la coneccion con la base de datos
mysqli_close($conexion);

?>