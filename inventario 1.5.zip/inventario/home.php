<?php
//se mantiene la sesion activa con el usuario que inicio sesion
session_start();
$Usuario = $_SESSION['Usuario'];
$varsesion= $_SESSION['Usuario'];
if($varsesion == null || $varsesion ='' ) {
    echo ' Como llegaste hasta aqui ?';
    die();
}
?>
<!DOCTYPE html> <!-- Declaración del tipo de documento HTML 5 -->

<html lang="español"> <!-- Etiqueta HTML que establece el idioma de la página es español -->

<head>
    <meta charset="UTF-8"> <!-- Configuración de caracteres UTF-8 para admitir caracteres especiales -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Configuración de la escala y el tamaño de la ventana para dispositivos móviles -->
    <title>Página de Inicio</title> <!-- Título de la página-->
    <link rel="stylesheet" href="./Styles/paguina de inicio.css"> <!-- Enlace a la hoja de estilos CSS para aplicar estilos a la página -->
</head>

<body>
    <header> <!-- Encabezado de la página -->
        <div class="user-info"> <!-- Contenedor de información del usuario -->
            <img src="./Styles/Imagenes/Logo normal.png" alt="Logo"> <!-- Imagen del logo del sitio web -->
            <h1>Herravida</h1> <!-- Título principal de la página -->
            </div>
        </div>
        <nav> <!-- Barra de navegación -->
            <ul> <!-- Lista de navegación -->
                <li><a href="inventario.php">Almacén</a></li> <!-- Elemento de la lista con un enlace "Almacén" -->
                <li><a class="logout-button" href="cerrar_sesion.php">Cerrar Sesión</a></li> <!-- Elemento de la lista con un enlace "Cerrar Sesión" que utiliza una clase "logout-button" -->
            </ul>
        </nav>
    </header>

    <!-- Elementos centrados en la página -->
    <center> <!-- La etiqueta "center" es obsoleta, se recomienda utilizar estilos CSS para centrar elementos en su lugar -->
         <!--regresa el campo del usuario -->
        <h1 class="bienvenido">Bienvenido <?php echo "<h1>BIENVENIDO DE VUELTA $Usuario</h1>";?>
    </h1> <!-- Título de bienvenida con un marcador de posición "(usuario)" -->
    </center>

    <center> <!-- La etiqueta "center" es obsoleta, se recomienda utilizar estilos CSS para centrar elementos en su lugar -->
        <img src="./Styles/Imagenes/Logo de inicio.png" alt="Imagen"> <!-- Imagen con texto alternativo "Imagen" -->
    </center>
</body>

</html>
