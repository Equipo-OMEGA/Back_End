<?php
//Abrimos una sesion
session_start();
//Destruimos la sesion iniciada
session_destroy();
//Una vez realizada la destruccion de la session nos redirigira al
//inicio de sesion
header("Location: index.html");
?>