<?php
include("conexion.php");
$conn = conectar();

$id_usuario = $_GET['id'];

$sql = "SELECT * FROM usuario WHERE id_usuario ='$id_usuario'";
$query = mysqli_query($conn, $sql);

$row = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <title>Actualizar Usuario</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            max-width: 500px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        h4 {
            margin-top: 20px;
            margin-bottom: 10px;
        }

        .btn-cancel {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-cancel:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h2 class="text-center">Actualizar Proveedor</h2>
            </div>
            <div class="card-body">
                <form action="update.php" method="POST" enctype="multipart/form-data">

                    <!-- Input oculto para el ID del proveedor -->
                    <input type="hidden" name="id_usuario" value="<?php echo $row['id_usuario'] ?>">

                    <div class="form-group">
                        <label for="calle">Nombre</label>
                        <input type="text" class="form-control" name="nombre_completo" placeholder="Nombre" value="<?php echo $row['nombre_completo'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="calle">Correo</label>
                        <input type="text" class="form-control" name="correo_electronico" placeholder="Correo" value="<?php echo $row['correo_electronico'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="calle">Usuario</label>
                        <input type="text" class="form-control" name="usuario" placeholder="Usuario" value="<?php echo $row['usuario'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="calle">Contraseña</label>
                        <input type="text" class="form-control" name="contraseña" placeholder="Contraseña" value="<?php echo str_repeat('*', strlen($row['contraseña'])); ?>" required>
                    </div>

                    <!-- Botones de Actualizar y Cancelar -->
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-block">Actualizar</button>
                        <a href="vista.php" class="btn btn-cancel btn-block">Cancelar</a>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous"></script>
</body>

</html>
