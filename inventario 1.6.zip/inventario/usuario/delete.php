<?php
// se crea la conexion a el archivo de "conexion" para poder realizar cambios en la base de datos
include("conexion.php");
// se define "con" como "conectar"
$conn=conectar();

// se realiza la conexion a la tabla y columna, por medio del id se elimina el dato 
//el id lo toma del boton de eliminar
$id_usuario=$_GET['id'];

// se crea un query que realiza una eliminacion a un dato en la base de datos
$sql="DELETE FROM usuario WHERE id_usuario ='$id_usuario'";
$query=mysqli_query($conn, $sql);

    // es la direccion de la cual va a realizar la operacion
    if($query){
        Header("location: vista.php");
    }
?>