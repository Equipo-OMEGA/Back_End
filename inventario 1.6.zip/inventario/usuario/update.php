<?php

// se crea una conexion a el archivo "conexion" para poder acceder a la base de datos
include("conexion.php");
$conn=conectar();

// se definen las columnas para poder actualizarlas
//Se escriben igual como estan en la base de datos
$id_usuario=$_POST['id_usuario'];
$nombre_completo=$_POST['nombre_completo'];
$correo_electronico=$_POST['correo_electronico'];
$usuario=$_POST['usuario'];
$contraseña=$_POST['contraseña'];

$id_usuario= mysqli_real_escape_string($conn, $id_usuario);
$nombre_completo = mysqli_real_escape_string($conn, $nombre_completo);
$correo_electronico = mysqli_real_escape_string($conn, $correo_electronico);
$usuario = mysqli_real_escape_string($conn, $usuario);

if(empty($contraseña) || $contraseña == str_repeat('*', strlen($contraseña))) {
    $sql = "UPDATE usuario SET nombre_completo = '$nombre_completo',
    correo_electronico='$correo_electronico', usuario='$usuario' WHERE
    id_usuario='$id_usuario'";
}else{
    $contraseña_segura = hash('sha512',$contraseña);
    $sql = "UPDATE usuario SET nombre_completo='$nombre_completo',
    correo_electronico='$correo_electronico', usuario='$usuario',
    contraseña='$contraseña_segura' WHERE id_usuario='$id_usuario'";
}

$query=mysqli_query($conn, $sql);

    // se crea el lugar a donde tiene que modificar
    if($query){
        Header("Location: vista.php");
    }else {
        echo "Hubo un error en la actualizacion" , mysqli_error($conn);
    }

    mysqli_close($conn);
?>