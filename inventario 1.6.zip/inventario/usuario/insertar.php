<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Agrega la referencia a Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Estilo para el cuerpo del documento */
        body {
            background-color: #f8f9fa; /* Fondo claro */
        }

        /* Estilo para el cuadro del formulario */
        .card {
            width: 400px; /* Ancho del cuadro */
            margin: 50px auto; /* Centra el cuadro horizontal y verticalmente */
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1); /* Sombra suave */
            border-radius: 10px; /* Bordes redondeados */
        }

        /* Estilo para el encabezado del formulario */
        .card-title {
            font-size: 28px; /* Tamaño de la fuente del encabezado */
            margin-bottom: 20px; /* Espacio inferior */
        }

        /* Estilo para etiquetas de formulario */
        label {
            font-size: 18px; /* Tamaño de la fuente de las etiquetas */
            margin-bottom: 5px; /* Espacio inferior */
        }

        /* Estilo para campos de entrada de texto */
        .form-control {
            font-size: 16px; /* Tamaño de la fuente de los campos de entrada */
            padding: 12px; /* Espaciado interno */
            margin-bottom: 15px; /* Espacio inferior */
            border-radius: 5px; /* Bordes redondeados */
        }

        /* Estilo para el botón de enviar */
        .btn-primary {
            font-size: 16px; /* Tamaño de la fuente del botón */
            padding: 10px; /* Espaciado interno */
            border-radius: 5px; /* Bordes redondeados */
        }
    </style>
</head>

<body>
  
    <div class="container">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title text-center mb-4">Formulario de Datos</h5>
                <form action="funsion_insertar.php" method="POST"  enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" class="form-control" name="nombre_completo" required>
                        </div>
                        <div class="form-group">
                            <label for="descripcion">correo_electronico</label>
                            <input type="text" class="form-control" name="correo_electronico" required>
                        </div>
                        <div class="form-group">
                            <label for="costo">usuario</label>
                            <input type="text" class="form-control" name="usuario" required>
                        </div>
                        <div class="form-group">
                            <label for="precio">contraseña</label>
                            <input type="text" class="form-control" name="contraseña" required>
                        </div>
                        <input type="submit" class="btn btn-primary">
                        <a href="vista.php" class="btn btn-info">Regresar</a>

                </form>
            </div>
        </div>
    </div>

    <!-- Agrega la referencia a Bootstrap JS y Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
