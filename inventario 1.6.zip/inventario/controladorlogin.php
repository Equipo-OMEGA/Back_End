<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<?php

//Obtiene los datos de los campos del login  
$Usuario=$_POST['Usuario'];
$Contraseña=$_POST['Contraseña'];
//Desemcripta la contraseña que se recupera de la base de datos
$Contraseña = hash('sha512', $Contraseña);
//se inicia la sesion del usuario registrado con ese campo
session_start();
$_SESSION['Usuario']=$Usuario;
//Hacemos una conexion a la base de datos en la cual se espesifica que sera de manera local, un usuario
//una contraseña ( en este caso no tiene la base de datos) y el nombre de la base de datos
$conexion=mysqli_connect("localhost:3306","root","","inventario");

//Hacemos una consulta a nuestra base de datos en la que seleccionara los campos y el contenido de este y lo 
//comparara con los datos dados por el usuario 
$consulta="SELECT * FROM usuario where Usuario='$Usuario' and Contraseña='$Contraseña'";
//Variable en donde se almacena el resultado de la consulta(sql, query) y la coneccion a la base de datos
$resultado=mysqli_query($conexion,$consulta);
//Esta variable regresa los resultados de la variable "resultados" 
$filas=mysqli_num_rows($resultado);

//si "filas tiene los resultados de la consulta y estos concuerdan con el correo electronico y la contraseña 
//de la base de datos, entonces mandara al usuario al archivo home
if($filas){ 
    header("location:home.php");

}else{
    ?>
    <?php
    include("index.html");
    ?>
    <script> 
    //Usuamos una
    Swal.fire({
    icon: "error",
    title: "Oops...",
    text: "Usuario y contraseña incorrectos vuelve a intentarlo!",
    }); 
    </script>

    <?php
}
mysqli_free_result($resultado);
//Cierra la coneccion con la base de datos
mysqli_close($conexion);
?> 
</body>
</html>

