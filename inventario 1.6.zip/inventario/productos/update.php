<?php

// se crea una conexion a el archivo "conexion" para poder acceder a la base de datos
include("conexion.php");
$conn=conectar();

// se definen las columnas para poder actualizarlas
//Se escriben igual como estan en la base de datos
$id_Articulo=$_POST['id_Articulo'];
$nombre=$_POST['nombre'];
$descripcion=$_POST['descripcion'];
$costo=$_POST['costo'];
$precio=$_POST['precio'];
$precio_mayoreo=$_POST['precio_mayoreo'];
$existencia_Almacen=$_POST['existencia_Almacen'];
$existencia_PisoVenta=$_POST['existencia_PisoVenta'];
$TipoArticulo=$_POST['TipoArticulo'];
$imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));

// la operacion que se busca realizar es modificar los valores que ya tiene un registro
$sql="UPDATE articulo SET id_Articulo='$id_Articulo', nombre='$nombre', descripcion='$descripcion', costo='$costo', precio='$precio',
 precio_mayoreo='$precio_mayoreo', existencia_Almacen='$existencia_Almacen', existencia_PisoVenta='$existencia_PisoVenta'
,TipoArticulo='$TipoArticulo', imagen='$imagen' WHERE id_Articulo='$id_Articulo'";
$query=mysqli_query($conn, $sql);

    // se crea el lugar a donde tiene que modificar
    if($query){
        Header("Location: vista.php");
    }
?>