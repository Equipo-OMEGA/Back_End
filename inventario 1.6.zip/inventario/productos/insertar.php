<!DOCTYPE html>
<html lang="es">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body class="bg-light">
    <div class="container mt-5">
        <a href="vista.php" class="btn btn-primary mb-4">regresar</a>
        <div class="card mx-auto" style="width: 400px; margin-top: 20px;">
            <div class="card-body">
                <h5 class="card-title text-center mb-4">Agregar Datos</h5>
                <form action="funcion_insertar.php" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" class="form-control" name="nombre" required>
                    </div>
                    <div class="form-group">
                        <label for="descripcion">Descripción</label>
                        <input type="text" class="form-control" name="descripcion" required>
                    </div>
                    <div class="form-group">
                        <label for="costo">Costo</label>
                        <input type="text" class="form-control" name="costo" required>
                    </div>
                    <div class="form-group">
                        <label for="precio">Precio</label>
                        <input type="text" class="form-control" name="precio" required>
                    </div>
                    <div class="form-group">
                        <label for="precio_mayoreo">Precio Mayoreo</label>
                        <input type="text" class="form-control" name="precio_mayoreo" required>
                    </div>
                    <div class="form-group">
                        <label for="existencia_Almacen">Existencia en Almacén</label>
                        <input type="text" class="form-control" name="existencia_Almacen" required>
                    </div>
                    <div class="form-group">
                        <label for="existencia_PisoVenta">Existencia en Piso de Venta</label>
                        <input type="n" class="form-control" name="existencia_PisoVenta" required>
                    </div>
                    <div class="form-group">
                        <label for="TipoArticulo">Tipo Artículo</label>
                        <input type="number" class="form-control" name="TipoArticulo" required>
                    </div>
                    <div class="form-group">
                        <label for="imagen">Imagen</label>
                        <input type="file" class="form-control-file" name="imagen">
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary btn-block" value="Enviar">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
