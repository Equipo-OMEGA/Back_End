<?php
include("conexion.php");
$conn = conectar();

// Manejar la búsqueda
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $buscar = mysqli_real_escape_string($conn, $_POST['buscar']);
    $sql = "SELECT * FROM articulo WHERE nombre LIKE '%$buscar%'";
    $query = mysqli_query($conn, $sql);
} else {
    // Si no hay búsqueda, obtener todos los registros
    $sql = "SELECT * FROM articulo";
    $query = mysqli_query($conn, $sql);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Artículos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Styles/paguina de inicio.css">
    <!-- Agregamos estilos personalizados para la tabla -->
    <style>
        th, td {
            text-align: center;
        }

        img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>

<body>
    <header>
        <div class="user-info">
            <img src="../Logo normal.png" alt="Logo">
            <h1>Herravida</h1>
        </div>
        <nav>
            <ul>
                <li><a href="../home.php">Inicio</a></li>
                <li><a class="logout-button" href="../cerrar_sesion.php">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </header>

    <div class="container mt-3">
        <a href="insertar.php" class="btn btn-primary">Agregar</a>
        <!-- Buscador -->
        <br><br>
        <form method="post" action="">
            <div class="input-group mb-3">
            <div class="input-group mb-3">
    <input type="text" class="form-control" placeholder="Buscar por nombre..." name="buscar" aria-label="Buscar" aria-describedby="button-addon2">
    <div class="input-group-append">
        <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Buscar</button>
    </div>
</div>

            </div>
        </form>
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>id_Articulo</th>
                        <th>Nombre</th>
                        <th>Descripcion</th>
                        <th>Costo</th>
                        <th>Precio</th>
                        <th>Precio mayoreo</th>
                        <th>Existencia Almacen</th>
                        <th>Existencia Piso Venta</th>
                        <th>Tipo Articulo</th>
                        <th>Imagen</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = mysqli_fetch_array($query)) {
                        ?>
                        <tr>
                            <th><?php echo $row['id_Articulo'] ?></th>
                            <td><?php echo $row['nombre'] ?></td>
                            <td><?php echo $row['descripcion'] ?></td>
                            <td><?php echo $row['costo'] ?></td>
                            <td><?php echo $row['precio'] ?></td>
                            <td><?php echo $row['precio_mayoreo'] ?></td>
                            <td><?php echo $row['existencia_Almacen'] ?></td>
                            <td><?php echo $row['existencia_PisoVenta'] ?></td>
                            <td><?php echo $row['TipoArticulo'] ?></td>
                            <td><img height="70px" src="data:image/jpg;base64,<?php echo base64_encode($row['imagen']); ?>" /></td>
                            <td><a href="actualizar.php?id=<?php echo $row['id_Articulo'] ?>" class="btn btn-info">Editar</a></td>
                            <td><a href="delete.php?id=<?php echo $row['id_Articulo'] ?>" class="btn btn-danger">Eliminar</a></td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap/dist/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs5/dt-1.13.1/datatables.min.js"></script>
    <script>
        $(document).ready(function () {
            // Inicializar DataTable
            $('.table').DataTable({
                language: {
                    url: 'https://cdn.datatables.net/plug-ins/1.13.4/i18n/es-MX.json',
                }
            });
        });
    </script>
</body>

</html>