<?php
// se crea una conexion a el archivo "conexion" para poder acceder a la base de datos
// esto es necesario ya que de no conectarse no se puede realizar algun cambio
include("conexion.php");
$conn=conectar();

// se definen las columnas para poder modificarlas
//Se escriben igual como estan en la base de datos
$nombre=$_POST['nombre'];
$descripcion=$_POST['descripcion'];
$costo=$_POST['costo'];
$precio=$_POST['precio'];
$precio_mayoreo=$_POST['precio_mayoreo'];
$existencia_Almacen=$_POST['existencia_Almacen'];
$existencia_PisoVenta=$_POST['existencia_PisoVenta'];
$TipoArticulo=$_POST['TipoArticulo'];
$imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));

// se crea un query que lo que hace es añadir datos a las columnas de una tabla por mediante de valores 
//Se agregan las columnas de la tabla de producto de la base de datos y despues los valores que queremos insertar
$sql=" INSERT INTO articulo (nombre, descripcion, costo, precio, precio_mayoreo, existencia_Almacen, existencia_PisoVenta, TipoArticulo, imagen) 
values('$nombre', '$descripcion', '$costo', '$preico', '$precio_mayoreo', '$existencia_Almacen', '$existencia_PisoVenta', '$TipoArticulo', '$imagen')";
$query=mysqli_query($conn, $sql);

// es la direccion de la cual se realizara la operacion
if($query){
    header("location: vista.php");

}else{
}
?>