<?php
// se crea una conexion a el archivo "conexion" para poder acceder a la base de datos
// esto es necesario ya que de no conectarse no se puede realizar algun cambio
include("conexion.php");
$conn=conectar();

// se definen las columnas para poder modificarlas
//Se escriben igual como estan en la base de datos
$descripcion=$_POST['descripcion'];

// se crea un query que lo que hace es añadir datos a las columnas de una tabla por mediante de valores 
//Se agregan las columnas de la tabla de producto de la base de datos y despues los valores que queremos insertar
$sql=" INSERT INTO tipo_articulo (descripcion) 
values('$descripcion')";
$query=mysqli_query($conn, $sql);

// es la direccion de la cual se realizara la operacion
if($query){
    header("location: vista.php");

}else{
}
?>