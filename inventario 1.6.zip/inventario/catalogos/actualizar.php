<?php
include("conexion.php");
$conn = conectar();

$id_TipoArticulo = $_GET['id'];

$sql = "SELECT * FROM tipo_articulo WHERE id_TipoArticulo ='$id_TipoArticulo'";
$query = mysqli_query($conn, $sql);

$row = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <title>Actualizar Catalogos</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            max-width: 500px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        h4 {
            margin-top: 20px;
            margin-bottom: 10px;
        }

        .btn-cancel {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-cancel:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h2 class="text-center">Actualizar Proveedor</h2>
            </div>
            <div class="card-body">
                <form action="update.php" method="POST" enctype="multipart/form-data">

                    <!-- Input oculto para el ID del proveedor -->
                    <input type="hidden" name="id_TipoArticulo" value="<?php echo $row['id_TipoArticulo'] ?>">

                    <div class="form-group">
                        <label for="calle">Descripcion</label>
                        <input type="text" class="form-control" name="descripcion" placeholder="Descripcion" value="<?php echo $row['descripcion'] ?>" required>
                    </div>

                    <!-- Botones de Actualizar y Cancelar -->
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-block">Actualizar</button>
                        <a href="vista.php" class="btn btn-cancel btn-block">Cancelar</a>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous"></script>
</body>

</html>
