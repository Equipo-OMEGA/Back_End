<?php

// se crea una conexion a el archivo "conexion" para poder acceder a la base de datos
include("conexion.php");
$conn=conectar();

// se definen las columnas para poder actualizarlas
//Se escriben igual como estan en la base de datos
$id_TipoArticulo=$_POST['id_TipoArticulo'];
$descripcion=$_POST['descripcion'];

// la operacion que se busca realizar es modificar los valores que ya tiene un registro
$sql="UPDATE tipo_articulo SET id_TipoArticulo='$id_TipoArticulo', descripcion='$descripcion' 
WHERE id_TipoArticulo='$id_TipoArticulo'";
$query=mysqli_query($conn, $sql);

    // se crea el lugar a donde tiene que modificar
    if($query){
        Header("Location: vista.php");
    }
?>