<?php
   //Hace la coneccion con la base de datos mediante el documento conexion.php
   include("conexion.php");
   //Conecta la base de datos
   $conn=conectar();
   //Consulta a la base de datos y me trae las columnas y filas de la tabla 
   $sql="SELECT *  FROM articulo";
   //Genera la consulta en la coneccion y asigna el resultado a query
   $query=mysqli_query($conn,$sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Productos</title>
    <link rel="stylesheet" type="text/css" href="./Styles/inventario.css">
</head>
<body>
    <header>
        <div class="user-info">
            <img src="./Styles/Imagenes/Logo normal.png" alt="Logo">
            <h1>Herravida</h1>
        </div>
        <div class="search-container">
            <input type="text" id="search" placeholder="Buscar...">
        </div>
        <nav>
            <ul>
                <li><a class="otroboton" href="home.php">inicio</a></li>
                <li><a class="logout-button" href="cerrar_sesion.php">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </header>

    <div class="content">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripcion</th>
                        <th>Costo</th>
                        <th>Precio</th>
                        <th>Precio_Mayoreo</th>
                        <th>Existencia_Almacen</th>
                        <th>Existencias_PisoVenta<th>
                        <th>Editar<th>
                        <th>Eliminar<th>
                    </tr>
                </thead>
                <tbody>
                    <!--Me agrega lo que hay de la base de datos lo agrega a la 
                            tabla en sus apartados correspondientes-->
                            <?php
                                //esta condicion lo que hace es hacer hacer un bucle que recorre todo los registros devueltos 
                                //por la consula, asignando cada registro a la variable "row y me los muestra en la tabla"
                                    while($row=mysqli_fetch_array($query)){
                                ?>
                                    <tr>
                                        <!--th indica que se trata de una celda en mi tabla y el codigo php echo row agarra el valor que tengo 
                                        en la base de datos que seria cod_Usuario y lo imprime en la tabla -->
                                        <th><?php echo $row['id_Articulo']?></th>
                                        <th><?php echo $row['nombre']?></th>
                                        <th><?php echo $row['descripcion']?></th>
                                        <th><?php echo $row['costo']?></th>
                                        <th><?php echo $row['precio']?></th>
                                        <th><?php echo $row['precio_mayoreo']?></th>
                                        <th><?php echo $row['existencia_Almacen']?></th>
                                        <th><?php echo $row['existencia_PisoVenta']?></th>
                                    </tr>
                                <?php
                                    }
                                ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>